package com.example.tvlauncher

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ResolveInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface
import java.security.SecureRandom
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private class Item(val pkg: String?, val label: String, val icon: Drawable?)

    private var unit = 1f
    private lateinit var rv: RecyclerView
    private lateinit var adapter: TileAdapter
    private val prefs by lazy { getSharedPreferences("launcher", Context.MODE_PRIVATE) }

    private fun u(v: Int): Int = (v * unit).toInt()

    private lateinit var gear: View
    private lateinit var wifi: View
    private lateinit var photoBtn: View
    private lateinit var bgView: ImageView
    private lateinit var rootView: FrameLayout
    private var overlay: FrameLayout? = null
    private var overlayStatus: TextView? = null
    private var server: BgServer? = null
    private lateinit var clockBox: LinearLayout
    private var lastPos = 0
    private var lastKey = ""
    private var focusTries = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        unit = resources.displayMetrics.heightPixels / 540f
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY

        val root = FrameLayout(this)
        rootView = root
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#0B1020"), Color.parseColor("#141C33"), Color.parseColor("#0B1020"))
        )

        // ảnh nền + lớp tối nhẹ cho dễ đọc chữ
        val bg = ImageView(this)
        bgView = bg
        bg.scaleType = ImageView.ScaleType.CENTER_CROP
        applyBg()
        root.addView(bg, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val shade = View(this)
        shade.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#96000000"), Color.parseColor("#00000000"), Color.parseColor("#00000000"), Color.parseColor("#BE000000"))
        )
        root.addView(shade, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // đồng hồ
        clockBox = LinearLayout(this)
        clockBox.orientation = LinearLayout.VERTICAL
        val clock = TextClock(this)
        clock.format24Hour = "HH:mm"
        clock.format12Hour = "HH:mm"
        clock.setTextColor(Color.WHITE)
        clock.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, u(64).toFloat())
        clock.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        val date = TextClock(this)
        date.format24Hour = "EEEE, dd/MM/yyyy"
        date.format12Hour = "EEEE, dd/MM/yyyy"
        date.setTextColor(Color.WHITE)
        date.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, u(20).toFloat())
        clockBox.addView(clock)
        clockBox.addView(date)
        root.addView(clockBox, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { leftMargin = u(72); topMargin = u(16) })

        // hàng ô ứng dụng
        rv = RecyclerView(this)
        rv.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rv.clipToPadding = false
        rv.clipChildren = false
        root.clipChildren = false
        rv.itemAnimator = null
        // khung nền chung (trong suốt) chứa tất cả logo
        val panel = GradientDrawable()
        panel.cornerRadius = u(22).toFloat()
        panel.setColor(Color.parseColor("#961A2342"))
        panel.setStroke(u(1), Color.parseColor("#3C486E"))
        rv.background = panel
        adapter = TileAdapter()
        rv.adapter = adapter
        root.addView(rv, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, u(108), Gravity.BOTTOM
        ).apply { leftMargin = u(78); rightMargin = u(78); bottomMargin = u(20) })

        // nút cài đặt (bánh răng) góc trên bên phải
        gear = GearView(this, 0)
        root.addView(gear, FrameLayout.LayoutParams(u(24), u(24), Gravity.TOP or Gravity.END)
            .apply { rightMargin = u(72); topMargin = u(30) })
        // biểu tượng Internet bên trái bánh răng
        wifi = GearView(this, 1)
        root.addView(wifi, FrameLayout.LayoutParams(u(24), u(24), Gravity.TOP or Gravity.END)
            .apply { rightMargin = u(72) + u(24) + u(12); topMargin = u(30) })

        // biểu tượng ảnh nền (đổi ảnh từ điện thoại), bên trái biểu tượng Wi-Fi
        photoBtn = GearView(this, 2)
        root.addView(photoBtn, FrameLayout.LayoutParams(u(24), u(24), Gravity.TOP or Gravity.END)
            .apply { rightMargin = u(72) + 2 * (u(24) + u(12)); topMargin = u(30) })

        setContentView(root)

        // chạy hiệu ứng mở đầu khi vừa bật TV (khởi động lại) hoặc khi TV vừa thoát chế độ chờ
        if (isNewBoot()) prefs.edit().putBoolean("playIntro", true).apply()
        try { registerReceiver(screenReceiver, IntentFilter(Intent.ACTION_SCREEN_OFF)) } catch (e: Exception) {}
    }

    override fun onDestroy() {
        closeBgOverlay()
        try { unregisterReceiver(screenReceiver) } catch (e: Exception) {}
        super.onDestroy()
    }

    override fun onPause() {
        closeBgOverlay()
        if (introRunning) finishIntro()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (prefs.getBoolean("playIntro", false)) {
            prefs.edit().putBoolean("playIntro", false).apply()
            prepareIntro()
        }
        reload()
        if (introStartPending) {
            introStartPending = false
            introTries = 0
            waitAndStart()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // bấm Home khi đang ở launcher: về ô đầu tiên
        if (introRunning) finishIntro()
        lastPos = 0
        rv.scrollToPosition(0)
        ensureFocus()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (overlay != null) { closeBgOverlay(); return }
        // màn hình chính: không thoát
    }

    // ---------- đổi ảnh nền từ điện thoại ----------
    private fun customBgFile() = File(filesDir, "bg_custom.jpg")

    // dùng ảnh người dùng đã gửi, nếu không có thì dùng ảnh gốc trong app
    private fun applyBg() {
        var done = false
        val f = customBgFile()
        if (f.exists()) {
            try {
                val o = BitmapFactory.Options()
                o.inJustDecodeBounds = true
                BitmapFactory.decodeFile(f.path, o)
                var s = 1
                while (o.outWidth / (s * 2) >= 1920) s *= 2
                val o2 = BitmapFactory.Options()
                o2.inSampleSize = s
                val bmp = BitmapFactory.decodeFile(f.path, o2)
                if (bmp != null) { bgView.setImageBitmap(bmp); done = true }
            } catch (e: Throwable) {}
        }
        if (!done) bgView.setImageResource(R.drawable.bg_home)
    }

    private fun localIp(): String? {
        try {
            var best: String? = null
            val en = NetworkInterface.getNetworkInterfaces()
            while (en != null && en.hasMoreElements()) {
                val ni = en.nextElement()
                if (!ni.isUp || ni.isLoopback) continue
                val ads = ni.inetAddresses
                while (ads.hasMoreElements()) {
                    val a = ads.nextElement()
                    if (a is Inet4Address && !a.isLoopbackAddress) {
                        val n = ni.name.lowercase()
                        if (n.startsWith("wlan") || n.startsWith("eth")) return a.hostAddress
                        if (best == null) best = a.hostAddress
                    }
                }
            }
            return best
        } catch (e: Exception) { return null }
    }

    private fun makeQr(text: String, size: Int): Bitmap? {
        return try {
            val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size)
            val px = IntArray(size * size)
            for (y in 0 until size) for (x in 0 until size) px[y * size + x] = if (m.get(x, y)) Color.BLACK else Color.WHITE
            Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888)
        } catch (e: Throwable) { null }
    }

    private fun overlayButton(text: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, u(18).toFloat())
        t.gravity = Gravity.CENTER
        t.setPadding(u(22), u(10), u(22), u(10))
        t.isFocusable = true
        t.isClickable = true
        fun bgFor(focus: Boolean) {
            val g = GradientDrawable()
            g.cornerRadius = u(14).toFloat()
            g.setColor(Color.parseColor(if (focus) "#EB2A3866" else "#55324468"))
            if (focus) g.setStroke(u(3), Color.WHITE)
            t.background = g
        }
        bgFor(false)
        t.setOnFocusChangeListener { _, has -> bgFor(has) }
        t.setOnClickListener { onClick() }
        return t
    }

    private fun showBgOverlay() {
        if (overlay != null) return
        val ip = localIp()
        val token = run {
            val chars = "abcdefghjkmnpqrstuvwxyz23456789"
            val r = SecureRandom()
            val sb = StringBuilder()
            for (i in 0 until 6) sb.append(chars[r.nextInt(chars.length)])
            sb.toString()
        }
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        box.setPadding(u(40), u(24), u(40), u(24))
        val card = GradientDrawable()
        card.cornerRadius = u(24).toFloat()
        card.setColor(Color.parseColor("#F01A2342"))
        card.setStroke(u(1), Color.parseColor("#3C486E"))
        box.background = card

        val title = TextView(this)
        title.text = "Đổi ảnh nền từ điện thoại"
        title.setTextColor(Color.WHITE)
        title.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, u(26).toFloat())
        box.addView(title)

        val srv = BgServer(filesDir, token, {
            runOnUiThread { applyBg(); overlayStatus?.text = "Đã nhận ảnh mới. Xem thử ở màn hình chính." }
        }, {
            runOnUiThread { applyBg(); overlayStatus?.text = "Đã khôi phục ảnh gốc." }
        })
        val ok = ip != null && srv.start()
        val status = TextView(this)
        status.setTextColor(Color.parseColor("#C7D2F0"))
        status.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, u(16).toFloat())
        status.gravity = Gravity.CENTER
        overlayStatus = status

        if (ok) {
            server = srv
            val url = "http://$ip:${srv.port}/?k=$token"
            val qr = makeQr(url, u(210))
            if (qr != null) {
                val iv = ImageView(this)
                iv.setImageBitmap(qr)
                iv.setPadding(u(8), u(8), u(8), u(8))
                iv.setBackgroundColor(Color.WHITE)
                box.addView(iv, LinearLayout.LayoutParams(u(226), u(226)).apply { topMargin = u(14) })
            }
            val urlT = TextView(this)
            urlT.text = url
            urlT.setTextColor(Color.WHITE)
            urlT.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, u(18).toFloat())
            urlT.gravity = Gravity.CENTER
            box.addView(urlT, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = u(10) })
            status.text = "Điện thoại cùng WiFi với TV: quét mã QR rồi chọn ảnh."
        } else {
            status.text = "Không mở được kết nối. Hãy kiểm tra TV đã kết nối WiFi chưa."
        }
        box.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = u(8) })

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val reset = overlayButton("Khôi phục ảnh gốc") {
            customBgFile().delete()
            applyBg()
            overlayStatus?.text = "Đã khôi phục ảnh gốc."
        }
        val close = overlayButton("Đóng") { closeBgOverlay() }
        row.addView(reset)
        row.addView(close, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = u(16) })
        box.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = u(16) })

        val ov = FrameLayout(this)
        ov.setBackgroundColor(Color.parseColor("#B0000000"))
        ov.isClickable = true
        ov.addView(box, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        rootView.addView(ov, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        overlay = ov
        close.requestFocus()
    }

    private fun closeBgOverlay() {
        val ov = overlay ?: return
        overlay = null
        overlayStatus = null
        try { server?.stop() } catch (e: Exception) {}
        server = null
        rootView.removeView(ov)
        ensureFocus()
    }

    // ---------- hiệu ứng mở đầu ----------
    private var introRunning = false
    private var introStartPending = false
    private var introTries = 0
    private val introAnims = ArrayList<Animator>()
    private val INTRO_DELAY_MS = 3500L   // chờ TV bật đèn nền rồi mới chạy hiệu ứng
    private var introCover: View? = null
    private var introStartAt = 0L

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_SCREEN_OFF) {
                prefs.edit().putBoolean("playIntro", true).apply()
            }
        }
    }

    // true nếu đây là lần chạy đầu tiên sau khi TV khởi động lại
    private fun isNewBoot(): Boolean {
        val count = try { Settings.Global.getInt(contentResolver, Settings.Global.BOOT_COUNT, -1) } catch (e: Exception) { -1 }
        if (count >= 0) {
            val last = prefs.getInt("bootCount", -1)
            if (count != last) { prefs.edit().putInt("bootCount", count).apply(); return true }
            return false
        }
        val bootTime = System.currentTimeMillis() - SystemClock.elapsedRealtime()
        val last = prefs.getLong("bootTime", 0L)
        if (last == 0L || Math.abs(bootTime - last) > 5 * 60 * 1000L) {
            prefs.edit().putLong("bootTime", bootTime).apply()
            return true
        }
        return false
    }

    // ẩn mọi thứ, chỉ còn ảnh nền
    private fun prepareIntro() {
        if (introRunning) return
        introRunning = true
        introStartPending = true
        introStartAt = SystemClock.elapsedRealtime()
        val cover = View(this)
        cover.setBackgroundColor(Color.BLACK)
        rootView.addView(cover, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        introCover = cover
        rv.alpha = 0f
        rv.translationY = u(140).toFloat()
        clockBox.alpha = 0f
        gear.alpha = 0f
        wifi.alpha = 0f
        photoBtn.alpha = 0f
    }

    private fun waitAndStart() {
        rv.post {
            if (!introRunning) return@post
            if (rv.childCount == 0 || rv.width == 0) {
                if (introTries++ < 30) rv.postDelayed({ waitAndStart() }, 50) else finishIntro()
                return@post
            }
            val wait = INTRO_DELAY_MS - (SystemClock.elapsedRealtime() - introStartAt)
            rv.postDelayed({
                if (!introRunning) return@postDelayed
                // hiện ảnh nền trước, rồi mới chạy trình tự
                introCover?.animate()?.alpha(0f)?.setDuration(500)?.withEndAction { removeIntroCover() }?.start()
                rv.postDelayed({ if (introRunning) runIntro() }, 500)
            }, if (wait > 0) wait else 0L)
        }
    }

    private fun removeIntroCover() {
        val c = introCover ?: return
        introCover = null
        try { c.animate().cancel() } catch (e: Exception) {}
        try { rootView.removeView(c) } catch (e: Exception) {}
    }

    private fun runIntro() {
        val slots = ArrayList<View>()
        val blocks = ArrayList<View>()
        for (i in 0 until rv.childCount) {
            val child = rv.getChildAt(i)
            slots.add(child)
            val vh = rv.getChildViewHolder(child)
            if (vh is TileAdapter.VH) blocks.add(vh.block)
        }

        // 1) khung nền trượt từ dưới lên
        val panelUp = ObjectAnimator.ofFloat(rv, View.TRANSLATION_Y, u(140).toFloat(), 0f)
        panelUp.duration = 700
        panelUp.interpolator = DecelerateInterpolator(2f)
        val panelFade = ObjectAnimator.ofFloat(rv, View.ALPHA, 0f, 1f)
        panelFade.duration = 400
        introAnims.add(panelUp)
        introAnims.add(panelFade)

        // 2) các logo trượt từ mép trái vào vị trí, logo bên trái tới trước
        var slideEnd = 700L
        for ((i, slot) in slots.withIndex()) {
            val startX = -(rv.left + slot.right + u(30)).toFloat()
            slot.translationX = startX
            val a = ObjectAnimator.ofFloat(slot, View.TRANSLATION_X, startX, 0f)
            a.duration = 800
            a.startDelay = 150L + i * 90L
            a.interpolator = DecelerateInterpolator(1.8f)
            introAnims.add(a)
            slideEnd = maxOf(slideEnd, 150L + i * 90L + 800L)
        }

        // 3) sau khi vào vị trí: cả hàng lượn sóng từ trái sang phải rồi dịu dần
        val amp = u(7).toFloat()
        val wave = ValueAnimator.ofFloat(0f, 1f)
        wave.duration = 2400
        wave.startDelay = slideEnd
        wave.interpolator = LinearInterpolator()
        wave.addUpdateListener { va ->
            val t = va.animatedValue as Float
            val env = 1f - t
            for ((i, b) in blocks.withIndex()) {
                val ph = t * 3f - i * 0.2f
                if (ph < 0f) continue
                val sv = Math.sin(ph.toDouble() * 2.0 * Math.PI).toFloat() * env
                b.translationY = -sv * amp
                val sc = 1f + 0.04f * sv
                b.scaleX = sc
                b.scaleY = sc
            }
        }
        wave.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                if (introRunning) {
                    for (b in blocks) { b.translationY = 0f; b.scaleX = 1f; b.scaleY = 1f }
                    fadeInTop()
                }
            }
        })
        introAnims.add(wave)

        panelUp.start()
        panelFade.start()
        for (a in introAnims) if (a !== panelUp && a !== panelFade) a.start()
    }

    // 4) cuối cùng: đồng hồ, ngày và hai biểu tượng nhỏ sáng dần
    private fun fadeInTop() {
        val set = AnimatorSet()
        val list = ArrayList<Animator>()
        for (v in listOf<View>(clockBox, gear, wifi, photoBtn)) list.add(ObjectAnimator.ofFloat(v, View.ALPHA, 0f, 1f))
        set.playTogether(list)
        set.duration = 900
        set.interpolator = AccelerateDecelerateInterpolator()
        set.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                if (introRunning) finishIntro()
            }
        })
        introAnims.add(set)
        set.start()
    }

    // kết thúc (hoặc bỏ qua) hiệu ứng: đưa mọi thứ về vị trí cuối
    private fun finishIntro() {
        val was = introRunning
        introRunning = false
        introStartPending = false
        val list = ArrayList(introAnims)
        introAnims.clear()
        for (a in list) a.cancel()
        removeIntroCover()
        rv.alpha = 1f
        rv.translationY = 0f
        for (i in 0 until rv.childCount) {
            val ch = rv.getChildAt(i)
            ch.translationX = 0f
            val vh = rv.getChildViewHolder(ch)
            if (vh is TileAdapter.VH) {
                vh.block.translationY = 0f
                vh.block.scaleX = 1f
                vh.block.scaleY = 1f
            }
        }
        clockBox.alpha = 1f
        gear.alpha = 1f
        wifi.alpha = 1f
        photoBtn.alpha = 1f
        if (was) ensureFocus()
    }

    // ---------- dữ liệu ----------
    private fun allApps(): List<ResolveInfo> {
        val pm = packageManager
        val a = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0)
        val b = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        return (a + b).distinctBy { it.activityInfo.packageName }.filter { it.activityInfo.packageName != packageName }
    }

    private fun defaultPackages(apps: List<ResolveInfo>): List<String> {
        val pm = packageManager
        fun find(pred: (String, String) -> Boolean): String? {
            for (ri in apps) {
                val label = ri.loadLabel(pm).toString().lowercase()
                if (pred(label, ri.activityInfo.packageName)) return ri.activityInfo.packageName
            }
            return null
        }
        val out = ArrayList<String>()
        find { l, p -> l.contains("youtube") && !l.contains("music") && !l.contains("kids") && !l.contains("studio") }?.let { out.add(it) }
        find { l, _ -> l.contains("vtv go") || l.contains("vtvgo") }?.let { out.add(it) }
        find { l, _ -> l.contains("fpt play") || l.contains("fptplay") }?.let { out.add(it) }
        find { l, p -> p == "com.example.xembongtv" || l.contains("xem bóng") || l.contains("xem bong") }?.let { out.add(it) }
        return out
    }

    private fun savedPackages(apps: List<ResolveInfo>): MutableList<String> {
        val raw = prefs.getString("apps", null)
        if (raw == null) {
            val d = defaultPackages(apps)
            prefs.edit().putString("apps", d.joinToString(",")).apply()
            return d.toMutableList()
        }
        return raw.split(",").filter { it.isNotBlank() }.toMutableList()
    }

    private fun savePackages(list: List<String>) {
        prefs.edit().putString("apps", list.joinToString(",")).apply()
    }

    private fun reload() {
        val pm = packageManager
        val apps = allApps()
        val byPkg = apps.associateBy { it.activityInfo.packageName }
        val items = ArrayList<Item>()
        for (p in savedPackages(apps)) {
            val ri = byPkg[p] ?: continue   // app đã gỡ thì bỏ qua
            items.add(Item(p, ri.loadLabel(pm).toString(), ri.loadIcon(pm)))
        }
        items.add(Item(null, "Thêm", null))
        val key = items.joinToString("|") { (it.pkg ?: "+") }
        if (key != lastKey) {
            lastKey = key
            adapter.submit(items)
            if (lastPos >= items.size) lastPos = items.size - 1
        }
        ensureFocus()
    }

    // đưa focus về ô cuối cùng được chọn; thử lại vài lần nếu các ô chưa dựng xong
    private fun ensureFocus() {
        focusTries = 0
        tryFocus()
    }

    private fun tryFocus() {
        if (introRunning || overlay != null) return
        rv.post {
            if (introRunning || overlay != null) return@post
            val n = adapter.itemCount
            if (n == 0) return@post
            val pos = lastPos.coerceIn(0, n - 1)
            val vh = rv.findViewHolderForAdapterPosition(pos)
            if (vh != null) {
                if (!vh.itemView.hasFocus()) vh.itemView.requestFocus()
            } else if (focusTries++ < 15) {
                rv.scrollToPosition(pos)
                rv.postDelayed({ tryFocus() }, 80)
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) ensureFocus()
    }

    // nếu bấm phím điều hướng mà chưa có ô nào được chọn thì chọn lại ô trước đó
    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        if (event.action == android.view.KeyEvent.ACTION_DOWN) {
            val k = event.keyCode
            if (introRunning) { finishIntro(); return true }
            if (overlay != null) return super.dispatchKeyEvent(event)
            if (k == android.view.KeyEvent.KEYCODE_SETTINGS) { openSettings(); return true }
            // phím số 1-9: mở ứng dụng theo thứ tự hiện tại từ trái sang phải (ô dấu + không tính)
            val digit = when (k) {
                in android.view.KeyEvent.KEYCODE_1..android.view.KeyEvent.KEYCODE_9 -> k - android.view.KeyEvent.KEYCODE_1 + 1
                in android.view.KeyEvent.KEYCODE_NUMPAD_1..android.view.KeyEvent.KEYCODE_NUMPAD_9 -> k - android.view.KeyEvent.KEYCODE_NUMPAD_1 + 1
                else -> 0
            }
            if (digit > 0) {
                if (event.repeatCount == 0) {
                    val target = adapter.pkgAt(digit - 1)
                    if (target != null) launch(target)
                }
                return true
            }
            // quay vòng: bấm phải ở ô cuối -> về ô đầu; bấm trái ở ô đầu -> sang ô cuối (dấu +)
            val cur = currentFocus
            if (cur != null && cur !== gear && cur !== wifi && cur !== photoBtn && rv.hasFocus() &&
                (k == android.view.KeyEvent.KEYCODE_DPAD_LEFT || k == android.view.KeyEvent.KEYCODE_DPAD_RIGHT)) {
                val itemView = rv.findContainingItemView(cur)
                val pos = if (itemView != null) rv.getChildAdapterPosition(itemView) else -1
                val n = adapter.itemCount
                if (pos >= 0 && n > 1) {
                    if (k == android.view.KeyEvent.KEYCODE_DPAD_RIGHT && pos == n - 1) { jumpTo(0); return true }
                    if (k == android.view.KeyEvent.KEYCODE_DPAD_LEFT && pos == 0) { jumpTo(n - 1); return true }
                }
            }
            val nav = k == android.view.KeyEvent.KEYCODE_DPAD_LEFT || k == android.view.KeyEvent.KEYCODE_DPAD_RIGHT ||
                k == android.view.KeyEvent.KEYCODE_DPAD_UP || k == android.view.KeyEvent.KEYCODE_DPAD_DOWN ||
                k == android.view.KeyEvent.KEYCODE_DPAD_CENTER || k == android.view.KeyEvent.KEYCODE_ENTER
            val f = currentFocus
            if (nav && (f == null || (f !== gear && f !== wifi && f !== photoBtn && !rv.hasFocus()))) {
                ensureFocus()
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun jumpTo(p: Int) {
        lastPos = p
        rv.scrollToPosition(p)
        focusTries = 0
        tryFocus()
    }

    private fun openWifi() {
        try {
            val i = Intent(Settings.ACTION_WIFI_SETTINGS)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            openSettings()
        }
    }

    private fun openSettings() {
        try {
            val i = Intent(Settings.ACTION_SETTINGS)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "Không mở được Cài đặt", Toast.LENGTH_SHORT).show()
        }
    }

    // hai nút nhỏ góc trên bên phải: bánh răng (Cài đặt) và Wi-Fi (Internet), tự vẽ
    private inner class GearView(ctx: Context, private val kind: Int) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rect = RectF()
        init {
            isFocusable = true
            isClickable = true
            setBtnBg(this, false)
            setOnClickListener { when (kind) { 1 -> openWifi(); 2 -> showBgOverlay(); else -> openSettings() } }
            setOnFocusChangeListener { v, has ->
                setBtnBg(v, has)
                v.animate().scaleX(if (has) 1.2f else 1f).scaleY(if (has) 1.2f else 1f).setDuration(120).start()
            }
        }
        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val cx = w / 2f
            p.color = Color.WHITE
            if (kind == 2) {
                val h = height.toFloat()
                p.style = Paint.Style.STROKE
                p.strokeWidth = w * 0.07f
                p.strokeJoin = Paint.Join.ROUND
                p.strokeCap = Paint.Cap.ROUND
                rect.set(w * 0.12f, h * 0.2f, w * 0.88f, h * 0.8f)
                c.drawRoundRect(rect, w * 0.1f, w * 0.1f, p)
                val mt = Path()
                mt.moveTo(w * 0.2f, h * 0.72f)
                mt.lineTo(w * 0.42f, h * 0.5f)
                mt.lineTo(w * 0.55f, h * 0.63f)
                mt.lineTo(w * 0.68f, h * 0.5f)
                mt.lineTo(w * 0.82f, h * 0.72f)
                c.drawPath(mt, p)
                p.style = Paint.Style.FILL
                c.drawCircle(w * 0.32f, h * 0.4f, w * 0.07f, p)
            } else if (kind == 1) {
                val cy = height * 0.72f
                p.style = Paint.Style.STROKE
                p.strokeWidth = w * 0.065f
                p.strokeCap = Paint.Cap.ROUND
                for (rr in floatArrayOf(w * 0.14f, w * 0.27f, w * 0.40f)) {
                    rect.set(cx - rr, cy - rr, cx + rr, cy + rr)
                    c.drawArc(rect, 225f, 90f, false, p)
                }
                p.style = Paint.Style.FILL
                c.drawCircle(cx, cy, w * 0.06f, p)
            } else {
                val cy = height / 2f
                val r = minOf(width, height) * 0.2f
                p.style = Paint.Style.STROKE
                p.strokeWidth = r * 0.5f
                c.drawCircle(cx, cy, r, p)
                p.style = Paint.Style.FILL
                for (n in 0 until 8) {
                    c.save()
                    c.rotate(n * 45f, cx, cy)
                    c.drawRect(cx - r * 0.3f, cy - r * 1.7f, cx + r * 0.3f, cy - r * 1.15f, p)
                    c.restore()
                }
            }
        }
    }

    // ---------- hành động ----------
    private fun launch(pkg: String) {
        val pm = packageManager
        val i = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg)
        if (i == null) {
            Toast.makeText(this, "Không mở được ứng dụng này", Toast.LENGTH_SHORT).show()
            return
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(i) } catch (e: Exception) {
            Toast.makeText(this, "Không mở được ứng dụng này", Toast.LENGTH_SHORT).show()
        }
    }

    private fun removeApp(pkg: String, label: String) {
        val apps = allApps()
        val list = savedPackages(apps)
        list.remove(pkg)
        savePackages(list)
        Toast.makeText(this, "Đã gỡ $label khỏi màn hình", Toast.LENGTH_SHORT).show()
        reload()
    }

    private fun showAddDialog() {
        val pm = packageManager
        val apps = allApps().sortedBy { it.loadLabel(pm).toString().lowercase() }
        val labels = apps.map { it.loadLabel(pm).toString() }.toTypedArray()
        val current = savedPackages(apps)
        val checked = BooleanArray(apps.size) { current.contains(apps[it].activityInfo.packageName) }
        AlertDialog.Builder(this, androidx.appcompat.R.style.Theme_AppCompat_Dialog_Alert)
            .setTitle("Chọn ứng dụng hiển thị")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("Xong") { _, _ ->
                val selected = apps.indices.filter { checked[it] }.map { apps[it].activityInfo.packageName }
                // giữ thứ tự cũ, ứng dụng mới thêm vào cuối
                val result = ArrayList<String>()
                for (p in current) if (selected.contains(p)) result.add(p)
                for (p in selected) if (!result.contains(p)) result.add(p)
                savePackages(result)
                reload()
            }
            .setNegativeButton("Huỷ", null)
            .show()
    }

    // ---------- giao diện ô ----------
    private inner class TileAdapter : RecyclerView.Adapter<TileAdapter.VH>() {
        private var items: List<Item> = emptyList()
        private var slotW = u(160)

        fun submit(list: List<Item>) {
            items = list
            // chia đều chiều ngang khung nền cho các ô
            val panelW = resources.displayMetrics.widthPixels - 2 * u(78)
            slotW = maxOf(panelW / maxOf(1, list.size), u(100))
            notifyDataSetChanged()
        }

        // ứng dụng ở vị trí i (null nếu là ô dấu + hoặc vượt quá số ô)
        fun pkgAt(i: Int): String? = items.getOrNull(i)?.pkg

        inner class VH(val slot: FrameLayout, val box: LinearLayout, val block: IconBlock) :
            RecyclerView.ViewHolder(slot)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val slot = FrameLayout(parent.context)
            slot.clipChildren = false
            slot.layoutParams = RecyclerView.LayoutParams(slotW, ViewGroup.LayoutParams.MATCH_PARENT)

            val box = LinearLayout(parent.context)
            box.orientation = LinearLayout.VERTICAL
            box.gravity = Gravity.CENTER
            box.isFocusable = true
            box.isClickable = true
            box.isLongClickable = true
            setBoxBg(box, false)
            slot.addView(box, FrameLayout.LayoutParams(u(115), u(115), Gravity.CENTER))

            val block = IconBlock(parent.context)
            box.addView(block, LinearLayout.LayoutParams(u(72), u(72)))

            box.setOnFocusChangeListener { v, has ->
                if (has) {
                    val iv = rv.findContainingItemView(v)
                    val pos = if (iv != null) rv.getChildAdapterPosition(iv) else -1
                    if (pos >= 0) lastPos = pos
                }
                setBoxBg(v, has)
                // hiệu ứng nổi: nâng lên, phóng to, đổ bóng
                v.animate()
                    .scaleX(if (has) 1.16f else 1f)
                    .scaleY(if (has) 1.16f else 1f)
                    .translationY(if (has) -u(12).toFloat() else 0f)
                    .translationZ(if (has) u(24).toFloat() else 0f)
                    .setDuration(180)
                    .start()
            }
            return VH(slot, box, block)
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val lp = h.slot.layoutParams
            if (lp.width != slotW) {
                lp.width = slotW
                h.slot.layoutParams = lp
            }
            val item = items[position]
            val pkg = item.pkg
            if (pkg == null) {
                h.block.setPlus()
                h.box.setOnClickListener { showAddDialog() }
                h.box.setOnLongClickListener { true }
            } else {
                h.block.setApp(item.icon)
                h.box.setOnClickListener { launch(pkg) }
                h.box.setOnLongClickListener { removeApp(pkg, item.label); true }
            }
        }

        override fun getItemCount() = items.size
    }

    // logo dạng khối 3D: thân khối có độ dày, ánh sáng bóng phía trên, bóng đổ phía dưới
    private inner class IconBlock(ctx: Context) : View(ctx) {
        private var icon: Drawable? = null
        private var base = Color.parseColor("#3A4A8A")
        private var plusMode = false
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rect = RectF()
        private val path = Path()

        fun setApp(d: Drawable?) {
            plusMode = false
            icon = d
            if (d != null) base = avgColor(d)
            invalidate()
        }

        fun setPlus() {
            plusMode = true
            icon = null
            base = Color.parseColor("#4A5A9A")
            invalidate()
        }

        private fun shade(c: Int, f: Float): Int = Color.rgb(
            (Color.red(c) * f).toInt().coerceIn(0, 255),
            (Color.green(c) * f).toInt().coerceIn(0, 255),
            (Color.blue(c) * f).toInt().coerceIn(0, 255)
        )

        private fun blend(a: Int, b: Int, t: Float): Int = Color.rgb(
            (Color.red(a) * (1 - t) + Color.red(b) * t).toInt(),
            (Color.green(a) * (1 - t) + Color.green(b) * t).toInt(),
            (Color.blue(a) * (1 - t) + Color.blue(b) * t).toInt()
        )

        // màu trung bình của logo để làm màu khối
        private fun avgColor(d: Drawable): Int {
            val fallback = Color.parseColor("#3A4A8A")
            return try {
                val bmp = Bitmap.createBitmap(8, 8, Bitmap.Config.ARGB_8888)
                val cv = Canvas(bmp)
                d.setBounds(0, 0, 8, 8)
                d.draw(cv)
                var r = 0L; var g = 0L; var b = 0L; var n = 0
                for (y in 0 until 8) for (x in 0 until 8) {
                    val px = bmp.getPixel(x, y)
                    if (Color.alpha(px) > 128) { r += Color.red(px); g += Color.green(px); b += Color.blue(px); n++ }
                }
                bmp.recycle()
                if (n == 0) return fallback
                var c = Color.rgb((r / n).toInt(), (g / n).toInt(), (b / n).toInt())
                val lum = (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0
                if (lum > 0.72) c = Color.rgb(236, 239, 246)
                if (lum < 0.18) c = blend(c, fallback, 0.6f)
                c
            } catch (e: Exception) {
                fallback
            }
        }

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val depth = h * 0.08f
            val left = w * 0.06f
            val right = w * 0.94f
            val top = h * 0.02f
            val bottom = h * 0.90f - depth
            val rad = w * 0.22f

            p.shader = null
            p.style = Paint.Style.FILL
            // bóng đổ mềm phía dưới
            for (k in 1..4) {
                p.color = Color.argb(22, 0, 0, 0)
                val e = k * h * 0.012f
                rect.set(left - e * 0.5f, top + depth + e, right + e * 0.5f, bottom + depth + e * 1.6f)
                c.drawRoundRect(rect, rad + e, rad + e, p)
            }
            // mặt bên (độ dày của khối)
            p.color = shade(base, 0.5f)
            rect.set(left, top + depth, right, bottom + depth)
            c.drawRoundRect(rect, rad, rad, p)

            // mặt trên: logo phủ kín, cắt theo cùng góc bo
            rect.set(left, top, right, bottom)
            path.reset()
            path.addRoundRect(rect, rad, rad, Path.Direction.CW)
            c.save()
            c.clipPath(path)
            p.shader = LinearGradient(0f, top, 0f, bottom, shade(base, 1.12f), shade(base, 0.88f), Shader.TileMode.CLAMP)
            c.drawRect(rect, p)
            p.shader = null
            if (plusMode) {
                p.style = Paint.Style.STROKE
                p.color = Color.WHITE
                p.strokeWidth = w * 0.08f
                p.strokeCap = Paint.Cap.ROUND
                val cx = (left + right) / 2f
                val cy = (top + bottom) / 2f
                val len = w * 0.2f
                c.drawLine(cx - len, cy, cx + len, cy, p)
                c.drawLine(cx, cy - len, cx, cy + len, p)
                p.strokeCap = Paint.Cap.BUTT
                p.style = Paint.Style.FILL
            } else {
                val ic = icon
                if (ic != null) {
                    ic.setBounds(left.toInt(), top.toInt(), right.toInt(), bottom.toInt())
                    ic.draw(c)
                }
            }
            // ánh sáng bóng nửa trên (phủ lên logo)
            val gh = top + (bottom - top) * 0.45f
            p.shader = LinearGradient(0f, top, 0f, gh, Color.argb(60, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
            c.drawRect(left, top, right, gh, p)
            p.shader = null
            c.restore()

            // viền sáng
            p.style = Paint.Style.STROKE
            p.strokeWidth = maxOf(1.5f, w * 0.012f)
            p.color = Color.argb(120, 255, 255, 255)
            rect.set(left, top, right, bottom)
            c.drawRoundRect(rect, rad, rad, p)
            p.style = Paint.Style.FILL
        }
    }

    // ô đang chọn có khung sáng riêng; ô không chọn không có khung (nằm trên khung nền chung)
    private fun setBoxBg(v: View, focused: Boolean) {
        if (focused) {
            val g = GradientDrawable()
            g.cornerRadius = u(20).toFloat()
            g.setColor(Color.parseColor("#EB2A3866"))
            g.setStroke(u(3), Color.WHITE)
            v.background = g
        } else {
            v.background = null
        }
    }

    private fun setBtnBg(v: View, focused: Boolean) {
        val g = GradientDrawable()
        g.cornerRadius = u(9).toFloat()
        if (focused) {
            g.setColor(Color.parseColor("#EB2A3866"))
            g.setStroke(u(2), Color.WHITE)
        } else {
            g.setColor(Color.parseColor("#C81A2342"))
            g.setStroke(u(1), Color.parseColor("#5A648C"))
        }
        v.background = g
    }
}
