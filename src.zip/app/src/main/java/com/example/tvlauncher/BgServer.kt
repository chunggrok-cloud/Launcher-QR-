package com.example.tvlauncher

import android.graphics.BitmapFactory
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.ServerSocket
import java.net.Socket

/**
 * Máy chủ web rất nhỏ chạy ngay trên TV, chỉ bật khi màn hình "Đổi ảnh nền" đang mở.
 * Điện thoại cùng WiFi mở trang này, chọn ảnh và gửi lên. Có mã bí mật (token) trong đường dẫn.
 */
class BgServer(
    private val dir: File,
    private val token: String,
    private val onImage: () -> Unit,
    private val onReset: () -> Unit
) {
    @Volatile private var running = false
    private var ss: ServerSocket? = null
    var port = 0
        private set

    fun start(): Boolean {
        for (p in 8080..8090) {
            try {
                ss = ServerSocket(p)
                port = p
                break
            } catch (e: Exception) { ss = null }
        }
        val s = ss ?: return false
        running = true
        Thread {
            while (running) {
                try {
                    val c = s.accept()
                    Thread { handle(c) }.start()
                } catch (e: Exception) {
                    if (!running) break
                }
            }
        }.start()
        return true
    }

    fun stop() {
        running = false
        try { ss?.close() } catch (e: Exception) {}
        ss = null
    }

    private fun readLine(inp: BufferedInputStream): String? {
        val sb = StringBuilder()
        while (sb.length < 8192) {
            val b = inp.read()
            if (b < 0) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) break
            if (b != '\r'.code) sb.append(b.toChar())
        }
        return sb.toString()
    }

    private fun reply(c: Socket, code: Int, type: String, body: ByteArray) {
        val msg = when (code) { 200 -> "OK"; 400 -> "Bad Request"; 403 -> "Forbidden"; 413 -> "Payload Too Large"; else -> "Not Found" }
        val head = "HTTP/1.1 $code $msg\r\nContent-Type: $type\r\nContent-Length: ${body.size}\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n"
        val o = c.getOutputStream()
        o.write(head.toByteArray())
        o.write(body)
        o.flush()
    }

    private fun text(c: Socket, code: Int, t: String) = reply(c, code, "text/plain; charset=utf-8", t.toByteArray())

    private fun handle(c: Socket) {
        try {
            c.soTimeout = 20000
            val inp = BufferedInputStream(c.getInputStream())
            val first = readLine(inp) ?: return
            val parts = first.split(" ")
            if (parts.size < 2) return
            val method = parts[0]
            val target = parts[1]
            var len = 0
            while (true) {
                val h = readLine(inp) ?: break
                if (h.isEmpty()) break
                if (h.lowercase().startsWith("content-length:")) len = h.substring(15).trim().toIntOrNull() ?: 0
            }
            val path = target.substringBefore('?')
            val query = if (target.contains('?')) target.substringAfter('?') else ""
            val k = query.split("&").firstOrNull { it.startsWith("k=") }?.substring(2)
            if (k != token) { text(c, 403, "Sai ma. Hay quet lai ma QR tren TV."); return }

            if (method == "GET" && (path == "/" || path == "/index.html")) {
                reply(c, 200, "text/html; charset=utf-8", PAGE.toByteArray())
            } else if (method == "POST" && path == "/upload") {
                if (len <= 0 || len > 12 * 1024 * 1024) { text(c, 413, "Anh qua lon hoac rong"); return }
                val buf = ByteArrayOutputStream(len)
                val tmp = ByteArray(16384)
                var left = len
                while (left > 0) {
                    val n = inp.read(tmp, 0, minOf(tmp.size, left))
                    if (n < 0) break
                    buf.write(tmp, 0, n)
                    left -= n
                }
                if (left > 0) { text(c, 400, "Thieu du lieu"); return }
                val bytes = buf.toByteArray()
                val o = BitmapFactory.Options()
                o.inJustDecodeBounds = true
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                if (o.outWidth <= 0 || o.outHeight <= 0) { text(c, 400, "Khong phai file anh"); return }
                val tmpFile = File(dir, "bg_custom.tmp")
                tmpFile.writeBytes(bytes)
                val dest = File(dir, "bg_custom.jpg")
                dest.delete()
                tmpFile.renameTo(dest)
                text(c, 200, "OK")
                onImage()
            } else if (method == "POST" && path == "/reset") {
                File(dir, "bg_custom.jpg").delete()
                text(c, 200, "OK")
                onReset()
            } else {
                text(c, 404, "Not found")
            }
        } catch (e: Exception) {
        } finally {
            try { c.close() } catch (e: Exception) {}
        }
    }

    companion object {
        const val PAGE = """<!doctype html><html lang="vi"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Đổi ảnh nền TV</title>
<style>
body{margin:0;font-family:-apple-system,Segoe UI,Roboto,sans-serif;background:#0f1530;color:#fff;padding:20px}
h1{font-size:22px;margin:0 0 6px} p{color:#b9c4e6;font-size:15px;line-height:1.4}
.btn{display:block;width:100%;box-sizing:border-box;padding:16px;margin-top:12px;border:0;border-radius:14px;font-size:17px;font-weight:600;color:#fff;background:#2f4fd8;text-align:center}
.btn.alt{background:#2a3358}.btn[disabled]{opacity:.45}
#pv{width:100%;border-radius:12px;margin-top:14px;display:none;aspect-ratio:16/9;object-fit:cover}
#st{margin-top:14px;font-size:16px;min-height:22px}
input[type=file]{display:none}
</style></head><body>
<h1>Đổi ảnh nền TV</h1>
<p>Chọn một ảnh nằm ngang (tỉ lệ 16:9 là đẹp nhất). Ảnh sẽ được gửi thẳng lên TV trong nhà bạn, không qua Internet.</p>
<label class="btn" for="f">Chọn ảnh từ điện thoại</label>
<input id="f" type="file" accept="image/*">
<img id="pv" alt="">
<button id="send" class="btn" disabled>Gửi lên TV</button>
<button id="reset" class="btn alt">Khôi phục ảnh gốc</button>
<div id="st"></div>
<script>
var k=new URLSearchParams(location.search).get('k'),blob=null,st=document.getElementById('st'),pv=document.getElementById('pv'),sd=document.getElementById('send');
document.getElementById('f').onchange=function(e){
 var file=e.target.files[0]; if(!file)return;
 var img=new Image(),url=URL.createObjectURL(file);
 img.onload=function(){
  var s=Math.min(1,1920/Math.max(img.width,img.height)),c=document.createElement('canvas');
  c.width=Math.round(img.width*s);c.height=Math.round(img.height*s);
  c.getContext('2d').drawImage(img,0,0,c.width,c.height);
  c.toBlob(function(b){blob=b;pv.src=URL.createObjectURL(b);pv.style.display='block';sd.disabled=false;st.textContent='Đã chọn ảnh, bấm "Gửi lên TV".';},'image/jpeg',0.9);
 };
 img.onerror=function(){st.textContent='Không đọc được ảnh này, hãy thử ảnh khác.';};
 img.src=url;
};
sd.onclick=function(){
 if(!blob)return; sd.disabled=true; st.textContent='Đang gửi...';
 fetch('/upload?k='+k,{method:'POST',body:blob}).then(function(r){return r.text().then(function(t){
  st.textContent=r.ok?'Xong! Ảnh nền TV đã đổi.':'Lỗi: '+t; sd.disabled=false;});})
 .catch(function(){st.textContent='Không kết nối được TV. Kiểm tra cùng WiFi và TV còn mở màn hình Đổi ảnh nền.';sd.disabled=false;});
};
document.getElementById('reset').onclick=function(){
 fetch('/reset?k='+k,{method:'POST'}).then(function(r){st.textContent=r.ok?'Đã khôi phục ảnh gốc.':'Lỗi';})
 .catch(function(){st.textContent='Không kết nối được TV.';});
};
</script></body></html>"""
    }
}
