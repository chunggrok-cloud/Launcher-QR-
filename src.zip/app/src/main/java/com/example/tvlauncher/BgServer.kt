package com.example.tvlauncher

import android.graphics.BitmapFactory
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.ServerSocket
import java.net.Socket

/**
 * Máy chủ web rất nhỏ chạy ngay trên TV, chỉ bật khi màn hình "Đổi ảnh nền" đang mở.
 * Điện thoại cùng WiFi mở trang này, chọn ảnh và gửi lên. Có mã bí mật (token) trong đường dẫn.
 */
class BgServer(
    private val dir: File,
    private val token: String,
    private val onImage: () -> Unit,
    private val onReset: () -> Unit
) {
    @Volatile private var running = false
    private var ss: ServerSocket? = null
    var port = 0
        private set

    fun start(): Boolean {
        for (p in 8080..8090) {
            try {
                ss = ServerSocket(p)
                port = p
                break
            } catch (e: Exception) { ss = null }
        }
        val s = ss ?: return false
        running = true
        Thread {
            while (running) {
                try {
                    val c = s.accept()
                    Thread { handle(c) }.start()
                } catch (e: Exception) {
                    if (!running) break
                }
            }
        }.start()
        return true
    }

    fun stop() {
        running = false
        try { ss?.close() } catch (e: Exception) {}
        ss = null
    }

    private fun readLine(inp: BufferedInputStream): String? {
        val sb = StringBuilder()
        while (sb.length < 8192) {
            val b = inp.read()
            if (b < 0) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) break
            if (b != '\r'.code) sb.append(b.toChar())
        }
        return sb.toString()
    }

    private fun reply(c: Socket, code: Int, type: String, body: ByteArray) {
        val msg = when (code) { 200 -> "OK"; 400 -> "Bad Request"; 403 -> "Forbidden"; 413 -> "Payload Too Large"; else -> "Not Found" }
        val head = "HTTP/1.1 $code $msg\r\nContent-Type: $type\r\nContent-Length: ${body.size}\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n"
        val o = c.getOutputStream()
        o.write(head.toByteArray())
        o.write(body)
        o.flush()
    }

    private fun text(c: Socket, code: Int, t: String) = reply(c, code, "text/plain; charset=utf-8", t.toByteArray())

    private fun handle(c: Socket) {
        try {
            c.soTimeout = 20000
            val inp = BufferedInputStream(c.getInputStream())
            val first = readLine(inp) ?: return
            val parts = first.split(" ")
            if (parts.size < 2) return
            val method = parts[0]
            val target = parts[1]
            var len = 0
            while (true) {
                val h = readLine(inp) ?: break
                if (h.isEmpty()) break
                if (h.lowercase().startsWith("content-length:")) len = h.substring(15).trim().toIntOrNull() ?: 0
            }
            val path = target.substringBefore('?')
            val query = if (target.contains('?')) target.substringAfter('?') else ""
            val k = query.split("&").firstOrNull { it.startsWith("k=") }?.substring(2)
            if (k != token) { text(c, 403, "Sai ma. Hay quet lai ma QR tren TV."); return }

            if (method == "GET" && (path == "/" || path == "/index.html")) {
                reply(c, 200, "text/html; charset=utf-8", PAGE.toByteArray())
            } else if (method == "POST" && path == "/upload") {
                if (len <= 0 || len > 12 * 1024 * 1024) { text(c, 413, "Anh qua lon hoac rong"); return }
                val buf = ByteArrayOutputStream(len)
                val tmp = ByteArray(16384)
                var left = len
                while (left > 0) {
                    val n = inp.read(tmp, 0, minOf(tmp.size, left))
                    if (n < 0) break
                    buf.write(tmp, 0, n)
                    left -= n
                }
                if (left > 0) { text(c, 400, "Thieu du lieu"); return }
                val bytes = buf.toByteArray()
                val o = BitmapFactory.Options()
                o.inJustDecodeBounds = true
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                if (o.outWidth <= 0 || o.outHeight <= 0) { text(c, 400, "Khong phai file anh"); return }
                val tmpFile = File(dir, "bg_custom.tmp")
                tmpFile.writeBytes(bytes)
                val dest = File(dir, "bg_custom.jpg")
                dest.delete()
                tmpFile.renameTo(dest)
                text(c, 200, "OK")
                onImage()
            } else if (method == "POST" && path == "/reset") {
                File(dir, "bg_custom.jpg").delete()
                text(c, 200, "OK")
                onReset()
            } else {
                text(c, 404, "Not found")
            }
        } catch (e: Exception) {
        } finally {
            try { c.close() } catch (e: Exception) {}
        }
    }

    companion object {
        const val PAGE = """<!doctype html><html lang="vi"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>Đổi ảnh nền TV</title>
<style>
body{margin:0;font-family:-apple-system,Segoe UI,Roboto,sans-serif;background:#0f1530;color:#fff;padding:18px;-webkit-user-select:none;user-select:none}
h1{font-size:22px;margin:0 0 6px} p{color:#b9c4e6;font-size:15px;line-height:1.4;margin:6px 0}
.btn{display:block;width:100%;box-sizing:border-box;padding:15px;margin-top:12px;border:0;border-radius:14px;font-size:17px;font-weight:600;color:#fff;background:#2f4fd8;text-align:center}
.btn.alt{background:#2a3358}.btn[disabled]{opacity:.45}
.row{display:flex;gap:8px;margin-top:10px}.row .btn{margin-top:0;padding:12px 4px;font-size:15px}
.on{background:#2f4fd8!important}
#box{display:none}
#stage{position:relative;width:100%;aspect-ratio:16/9;background:#000;border-radius:10px;overflow:hidden;touch-action:none;margin-top:12px;outline:2px solid #3c486e}
#cv{width:100%;height:100%;display:block}
#zr{width:100%;margin-top:12px}
#st{margin-top:14px;font-size:16px;min-height:22px}
input[type=file]{display:none}
</style></head><body>
<h1>Đổi ảnh nền TV</h1>
<p>Chọn ảnh, rồi kéo và chụm ngón tay để chỉnh cho vừa khung TV. Khung bên dưới có tỉ lệ đúng bằng màn hình TV.</p>
<label class="btn" for="f">Chọn ảnh từ điện thoại</label>
<input id="f" type="file" accept="image/*">
<div id="box">
 <div id="stage"><canvas id="cv" width="640" height="360"></canvas></div>
 <input id="zr" type="range" min="30" max="400" value="100">
 <p style="margin:2px 0 0;font-size:13px">Kéo để dời ảnh. Chụm hai ngón hoặc kéo thanh trượt để phóng to hoặc thu nhỏ.</p>
 <div class="row">
  <button id="mFill" class="btn alt on">Phủ kín</button>
  <button id="mFit" class="btn alt">Vừa khung</button>
  <button id="mReset" class="btn alt">Đặt lại</button>
 </div>
</div>
<button id="send" class="btn" disabled>Gửi lên TV</button>
<button id="reset" class="btn alt">Khôi phục ảnh gốc</button>
<div id="st"></div>
<script>
var k=new URLSearchParams(location.search).get('k');
var st=document.getElementById('st'),sd=document.getElementById('send'),cv=document.getElementById('cv'),stage=document.getElementById('stage'),zr=document.getElementById('zr');
var img=null,mode='fill',zoom=1,ox=0,oy=0;
function draw(c,W,H){
 var x=c.getContext('2d');
 x.fillStyle='#000';x.fillRect(0,0,W,H);
 if(!img)return;
 var iw=img.naturalWidth,ih=img.naturalHeight;
 // nền mờ từ chính ảnh (phóng to ảnh nhỏ để tạo độ mờ)
 var t=document.createElement('canvas');t.width=32;t.height=18;
 var tx=t.getContext('2d'),cs=Math.max(32/iw,18/ih);
 tx.drawImage(img,(32-iw*cs)/2,(18-ih*cs)/2,iw*cs,ih*cs);
 x.imageSmoothingEnabled=true;x.imageSmoothingQuality='high';
 x.drawImage(t,0,0,W,H);
 x.fillStyle='rgba(0,0,0,0.25)';x.fillRect(0,0,W,H);
 var base=(mode==='fill')?Math.max(W/iw,H/ih):Math.min(W/iw,H/ih);
 var sc=base*zoom,dw=iw*sc,dh=ih*sc;
 x.drawImage(img,W/2+ox*W-dw/2,H/2+oy*W-dh/2,dw,dh);
}
function redraw(){draw(cv,640,360);zr.value=Math.round(zoom*100);}
function setMode(m){mode=m;zoom=1;ox=0;oy=0;
 document.getElementById('mFill').className='btn alt'+(m==='fill'?' on':'');
 document.getElementById('mFit').className='btn alt'+(m==='fit'?' on':'');
 redraw();}
document.getElementById('mFill').onclick=function(){setMode('fill');};
document.getElementById('mFit').onclick=function(){setMode('fit');};
document.getElementById('mReset').onclick=function(){setMode(mode);};
zr.oninput=function(){zoom=zr.value/100;redraw();};
function clampZ(){zoom=Math.min(4,Math.max(0.3,zoom));ox=Math.min(1,Math.max(-1,ox));oy=Math.min(1,Math.max(-1,oy));}
var ptrs={},lastD=0;
stage.addEventListener('pointerdown',function(e){stage.setPointerCapture(e.pointerId);ptrs[e.pointerId]={x:e.clientX,y:e.clientY};lastD=0;});
stage.addEventListener('pointermove',function(e){
 var p=ptrs[e.pointerId];if(!p)return;
 var w=stage.getBoundingClientRect().width,ids=Object.keys(ptrs);
 if(ids.length===1){ox+=(e.clientX-p.x)/w;oy+=(e.clientY-p.y)/w;}
 p.x=e.clientX;p.y=e.clientY;
 if(ids.length>=2){
  var a=ptrs[ids[0]],b=ptrs[ids[1]],d=Math.hypot(a.x-b.x,a.y-b.y);
  if(lastD>0&&d>0)zoom*=d/lastD;
  lastD=d;
 }
 clampZ();redraw();
});
function up(e){delete ptrs[e.pointerId];lastD=0;}
stage.addEventListener('pointerup',up);stage.addEventListener('pointercancel',up);
stage.addEventListener('wheel',function(e){e.preventDefault();zoom*=(e.deltaY<0?1.06:0.94);clampZ();redraw();},{passive:false});
document.getElementById('f').onchange=function(e){
 var file=e.target.files[0];if(!file)return;
 var im=new Image(),url=URL.createObjectURL(file);
 im.onload=function(){img=im;document.getElementById('box').style.display='block';sd.disabled=false;setMode('fill');st.textContent='Chỉnh ảnh cho vừa khung rồi bấm "Gửi lên TV".';};
 im.onerror=function(){st.textContent='Không đọc được ảnh này, hãy thử ảnh khác.';};
 im.src=url;
};
sd.onclick=function(){
 if(!img)return;sd.disabled=true;st.textContent='Đang gửi...';
 var c=document.createElement('canvas');c.width=1920;c.height=1080;draw(c,1920,1080);
 c.toBlob(function(b){
  fetch('/upload?k='+k,{method:'POST',body:b}).then(function(r){return r.text().then(function(t){
   st.textContent=r.ok?'Xong! Ảnh nền TV đã đổi.':'Lỗi: '+t;sd.disabled=false;});})
  .catch(function(){st.textContent='Không kết nối được TV. Kiểm tra cùng WiFi và TV còn mở màn hình Đổi ảnh nền.';sd.disabled=false;});
 },'image/jpeg',0.9);
};
document.getElementById('reset').onclick=function(){
 fetch('/reset?k='+k,{method:'POST'}).then(function(r){st.textContent=r.ok?'Đã khôi phục ảnh gốc.':'Lỗi';})
 .catch(function(){st.textContent='Không kết nối được TV.';});
};
</script></body></html>"""
    }
}
